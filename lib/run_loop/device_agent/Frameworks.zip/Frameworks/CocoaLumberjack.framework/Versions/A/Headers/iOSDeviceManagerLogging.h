#import <Foundation/Foundation.h>

@interface iOSDeviceManagerLogging : NSObject

+ (void)startLumberjackLogging;

@end

